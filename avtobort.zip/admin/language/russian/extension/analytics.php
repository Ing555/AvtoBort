<?php
// Heading
$_['heading_title']    = 'Статистика';

// Text
$_['text_success']     = 'Настройки платформы успешно обновлены';
$_['text_list']        = 'Список платформ для ведения статистики';

// Column
$_['column_name']      = 'Название платформы';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'У Вас нет прав для управления этим модулем!';
