<?php
// Heading
$_['heading_title']	  			= 'OpenBay Pro';

// Text
$_['text_module']          		= 'Модули';
$_['text_installed']          	= 'Модуль OpenBay Pro успешно установлен. Для настроек перейдите в меню: "Дополнения > OpenBay Pro"!';
