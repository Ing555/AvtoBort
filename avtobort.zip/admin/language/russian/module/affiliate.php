<?php
// Heading
$_['heading_title']    = 'Партнерская программа';

$_['text_module']      = 'Модули';
$_['text_success']     = 'Настройки модуля обновлены!';
$_['text_edit']        = 'Редактирование модуля';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас нет прав для управления этим модулем!';