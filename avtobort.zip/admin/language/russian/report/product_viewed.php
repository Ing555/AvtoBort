<?php
// Heading
$_['heading_title']    = 'Отчет по просмотренным товарам';

// Text
$_['text_list']        = 'Список просмотренных товаров';
$_['text_success']     = 'Отчет по товарам успешно сброшен!';

// Column
$_['column_name']      = 'Наименование товара';
$_['column_model']     = 'Модель';
$_['column_viewed']    = 'Просмотров';
$_['column_percent']   = 'В процентах';

// Error
$_['error_permission'] = 'У Вас нет прав просматривать этот отчет!';